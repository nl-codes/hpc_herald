#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <ctype.h>

typedef struct {
    char word[50];
    int count;
} W;

W words[5000];
int wc = 0;

pthread_mutex_t lock;

typedef struct {
    char *t;
    long s;
    long e;
} T;

void add(char *w) {
    pthread_mutex_lock(&lock);
    for (int i = 0; i < wc; i++) {
        if (strcmp(words[i].word, w) == 0) {
            words[i].count++;
            pthread_mutex_unlock(&lock);
            return;
        }
    }
    strcpy(words[wc].word, w);
    words[wc].count = 1;
    wc++;
    pthread_mutex_unlock(&lock);
}

void *run(void *arg) {
    T *d = arg;
    char w[50];
    int p = 0;
    for (long i = d->s; i < d->e; i++) {
        char c = d->t[i];
        if (isalnum(c)) w[p++] = tolower(c);
        else {
            if (p > 0) {
                w[p] = 0;
                add(w);
                p = 0;
            }
        }
    }
    if (p > 0) {
        w[p] = 0;
        add(w);
    }
    return NULL;
}

int cmp(const void *a, const void *b) {
    return strcmp(((W*)a)->word, ((W*)b)->word);
}

int main(int n, char *a[]) {
    if (n != 3) return 0;

    int th = atoi(a[2]);
    FILE *f = fopen(a[1], "r");
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);

    char *buf = malloc(size+1);
    fread(buf, 1, size, f);
    buf[size] = 0;
    fclose(f);

    pthread_t t[th];
    T d[th];
    long slice = size / th;

    pthread_mutex_init(&lock, 0);

    for (int i = 0; i < th; i++) {
        d[i].t = buf;
        d[i].s = i * slice;
        d[i].e = (i == th - 1) ? size : (i + 1) * slice;
        pthread_create(&t[i], 0, run, &d[i]);
    }

    for (int i = 0; i < th; i++)
        pthread_join(t[i], 0);

    qsort(words, wc, sizeof(W), cmp);

    FILE *out = fopen("result.txt", "w");
    for (int i = 0; i < wc; i++)
        fprintf(out, "%s %d\n", words[i].word, words[i].count);
    fclose(out);

    return 0;
}
