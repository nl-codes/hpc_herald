#include <stdio.h>

// Extended prime multipliers for more complex hash
#define P1 69
#define P2 137
#define P3 17
#define P4 97
#define MODULUS 5432101 // Using a larger modulus for a larger search space

long encode(char *s)
{
    // Variables for the five characters
    long a, b, c, d, e, x;
    
    a = s[0]; // First letter
    b = s[1]; // Second letter
    c = s[2]; // Third letter
    d = s[3]; // Fourth letter
    e = s[4]; // Fifth letter

    // Extended encoding formula
    // x = ((((((a * P1) + b) * P2) + c) * P3 + d) * P4 + e)
    x = a;
    x = (x * P1) + b;
    x = (x * P2) + c;
    x = (x * P3) + d;
    x = (x * P4) + e;
    
    // Apply modulo
    // x = x % MODULUS;
    return x;
}

void main()
{
    // Array size increased to hold 5 chars + NULL terminator
    char s[6]; 
    long x;
    
    printf("Enter 5 lowercase letters: ");
    // Use %5s to safely read exactly 5 characters
    scanf("%5s", s); 
    
    s[5] = '\0'; // Null-terminate at the 6th position
    
    x = encode(s);
    printf("Code for %s is %ld\n", s, x);
}