#include <stdio.h>
#include <stdlib.h>
// Include omp.h only for the timing function, not for parallel execution
#include <omp.h> 

// Must match the encode function exactly
#define P1 69
#define P2 137
#define P3 17
#define P4 97
#define MODULUS 5432101

long encode(char *s)
{
    long a, b, c, d, e, x;
    
    a = s[0];
    b = s[1];
    c = s[2];
    d = s[3];
    e = s[4];

    x = a;
    x = (x * P1) + b;
    x = (x * P2) + c;
    x = (x * P3) + d;
    x = (x * P4) + e;
    
    // x = x % MODULUS;
    return x;
}

void main()
{
    char s[6]; 
    long x, y;
    int i, j, k, l, m; 
    
    // Timing variables
    double start_time, end_time;

    printf("Enter the code: ");
    scanf("%ld", &x);
    s[5] = '\0';
    
    // --- Start Timing ---
    start_time = omp_get_wtime();

    // Standard five nested 'for' loops (no OpenMP parallel or collapse directive)
    for(i=0; i<26; i++){        
    for(j=0; j<26; j++){        
    for(k=0; k<26; k++){        
    for(l=0; l<26; l++){        
    for(m=0; m<26; m++){        
        
        // Build the current 5-letter candidate string
        s[0] = i + 'a';
        s[1] = j + 'a';
        s[2] = k + 'a';
        s[3] = l + 'a';
        s[4] = m + 'a';
        s[5] = '\0';
        
        y = encode(s);
        
        if(x == y){
            end_time = omp_get_wtime(); // Capture time immediately upon finding the result
            printf("The letters for code %ld are %s\n", y, s);
            printf("Total time to decode: %lf seconds\n", end_time - start_time);
            exit(0); 
        }
    }
    }
    }
    }
    }
    
    // Fallback if the code is not found after search completes
    end_time = omp_get_wtime();
    printf("Code not found.\n");
    printf("Total time to search: %lf seconds\n", end_time - start_time);
}