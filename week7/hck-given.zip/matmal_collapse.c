#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define M 800  // Rows in A and C
#define N 400  // Cols in A, Rows in B
#define P 600  // Cols in B and C


int main(){
    
    double A[M][N], B[N][P], C[M][P];
    
    for(int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            A[i][j] = i + j;
        }
    }
    
    for(int i = 0; i < N; i++){
        for(int j = 0; j < P; j++){
            B[i][j] = i + j;
        }
    }
    
    //Initialize C
    for(int i = 0; i < M; i++){
        for(int j = 0; j < P; j++){
            C[i][j] = 0;
        }
    }

    
    double start = omp_get_wtime();
    #pragma omp parallel for collapse(3)
    for(int i = 0; i < M; i++){
        for(int j = 0; j < P; j++){
            for(int k = 0; k < N; k++){
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    double end = omp_get_wtime();
    printf("Time: %lf\n", end - start);
    
    // for(int i = 0; i < M; i++){
    //     for(int j = 0; j < P; j++){
    //         printf("%lf ", C[i][j]);
    //     }
    //     printf("\n");
    // }
    
}
    