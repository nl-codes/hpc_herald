#include <stdio.h>
#include <omp.h>
#define MAX 1000000

int main() {
    double average = 0.0, A[MAX];
    int i;

    // Initialize array
    for (i = 0; i < MAX; i++)
        A[i] = (double)i;

    // Parallel loop — THIS HAS A RACE CONDITION
    double start = omp_get_wtime();
    #pragma omp parallel for reduction(+:average)
    for (i = 0; i < MAX; i++) {
            average += A[i];   // ❌ multiple threads writing to average at same time            
    }

    average = average / MAX;
    double end = omp_get_wtime();
    printf("Time: %lf\n", end - start);
    printf("Average = %lf\n", average);

    return 0;
}