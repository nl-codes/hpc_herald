#include <time.h>

int time_difference(struct timespec *start, struct timespec *finish, 
                    long long int *difference) ;
