/****************************************************************************
  Parallel Matrix Multiplication Using POSIX Threads (pthreads)

  This program demonstrates how to multiply two matrices in parallel using
  pthreads by dividing the calculation by rows. Each thread computes a consecutive
  block of result rows. Threads work independently on their portion of the result
  matrix, so no synchronization is needed for the computation step itself.

  Key Concepts:
    - Matrix A of size M x N, matrix B of size N x P; result matrix C is M x P.
    - The number of threads is defined by THREADS.
    - Each thread receives a thread_arg_t structure with its assigned range of rows.
    - Each thread calculates the standard matrix multiplication formula for its rows:
        C[i][j] = sum(A[i][k] * B[k][j]) over k
    - This implementation is a practical, scalable way to speed up matrix multiplication
      when the matrices are large and there are multiple CPU cores available.

  Usage:
    - Change M, N, P, THREADS at top of file to desired sizes.
    - Compile with: gcc -o matmul_parallel matmul_parallel.c -pthread
    - Run without command-line arguments: Demo values are used for A and B.

  Note:
    - This example uses static allocation for simplicity (change to malloc for very large matrices).
    - See function comments for detailed explanations.
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define M 4   // Rows in A and C
#define N 4   // Cols in A, Rows in B
#define P 4   // Cols in B and C
#define THREADS 2

double A[M][N], B[N][P], C[M][P];

// Thread function to compute a subset of C's rows
typedef struct {
    int row_start, row_end;
} thread_arg_t;

void* multiply_rows(void* arg) {
    thread_arg_t* thread_arg = (thread_arg_t*)arg;
    for (int i = thread_arg->row_start; i < thread_arg->row_end; ++i) {
        for (int j = 0; j < P; ++j) {
            C[i][j] = 0.0;
            for (int k = 0; k < N; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return NULL;
}

int main() {
    // Initialize A and B for demonstration
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < N; ++j)
            A[i][j] = i + j + 1; // example values
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < P; ++j)
            B[i][j] = i * j + 1; // example values
    
    pthread_t threads[THREADS];
    thread_arg_t args[THREADS];
    int rows_per_thread = M / THREADS;
    
    for (int t = 0; t < THREADS; ++t) {
        args[t].row_start = t * rows_per_thread;
        args[t].row_end = (t == THREADS - 1) ? M : (t + 1) * rows_per_thread;
        pthread_create(&threads[t], NULL, multiply_rows, &args[t]);
    }
    for (int t = 0; t < THREADS; ++t)
        pthread_join(threads[t], NULL);
    
    // Print the result
    printf("\nMatrix C (Result):\n");
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < P; ++j)
            printf("%.1f ", C[i][j]);
        printf("\n");
    }
    return 0;
}
