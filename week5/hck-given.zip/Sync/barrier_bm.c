/*
    Simple Barrier Implementation Using Mutex and Busy Wait
    ------------------------------------------------------
    This program shows synchronization of multiple threads at a barrier
    (only proceeding when all have reached a certain point).
    A shared counter tracks arrivals; the counter
    is protected by a mutex, and each thread then spins (busy-waits) until it
    observes that all threads have reached the barrier.

    Limitations:
    - This barrier is usable only once per program run (single-use).
    - Busy-waiting wastes CPU cycles while spinning. For repeated/more efficient
      barriers, use condition variables, semaphores, or pthread_barrier_t.

    When to use: Demonstrates basic barrier logic and thread synchronization.
*/

#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

#define THREADS 3

int counter = 0;             // Tracks how many threads have arrived at the barrier
pthread_mutex_t barrier_mutex;


void* worker(void* arg) {
    printf("Thread %ld: working...\n", (long)arg);
    // Simulate independent work
    sleep(2);

// Enter barrier

    // Enter critical section to update counter
    pthread_mutex_lock(&barrier_mutex);
    counter++;
    pthread_mutex_unlock(&barrier_mutex);
    // Busy-wait until all threads have reached the barrier
    while (counter < THREADS) {
        // spin (do nothing, wastes CPU cycles)
    }

// Leave barrier


    printf("Thread %ld: starting next step.\n", (long)arg);
    return NULL;
}

int main() {
    pthread_t threads[THREADS];
    pthread_mutex_init(&barrier_mutex, NULL);
    for (long t = 0; t < THREADS; t++)
        pthread_create(&threads[t], NULL, worker, (void*)t);
    for (int t = 0; t < THREADS; t++)
        pthread_join(threads[t], NULL);
    pthread_mutex_destroy(&barrier_mutex);
    return 0;
}
