/*
    Robust reusable barrier using pthread condition variable and mutex.
    -----------------------------------------------------------------
    - counter: Tracks how many threads have arrived at the barrier.
    - mutex:   Guards counter and synchronizes threads entering/leaving the barrier.
    - cond_var: Threads block (without busy waiting) until everyone arrives.
    
    Barrier logic:
    * Each thread increments counter within a locked section.
    * If this thread is last to arrive, it resets the counter and broadcasts to release everyone.
    * Otherwise, it waits (inside a loop to protect against spurious wakeups!) for the broadcast.
    * When released, each thread unlocks the mutex and proceeds.
    
    Safe for multiple uses and all thread speeds; all threads are truly synchronized round after round.
*/

#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

#define THREAD_COUNT 4
#define ROUNDS 3

int counter = 0;                    // Shared arrival counter
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_var = PTHREAD_COND_INITIALIZER;

void barrier(int thread_count) {
    pthread_mutex_lock(&mutex);
    counter++;
    if (counter == thread_count) {
        // Last thread arrives: reset counter & unblock everyone.
        counter = 0;
        pthread_cond_broadcast(&cond_var); //unblocks all threads currently waiting on the specified condition variable cond_var
    } else {
        // Not last: wait until counter is reset/broadcast is made.
        while (pthread_cond_wait(&cond_var, &mutex) != 0) ///blocks the calling thread until another thread signals or broadcasts on cond_var and the thread reacquires the associated mutex.​
            ; // Always loop to avoid spurious wakeup risk!
    }
    pthread_mutex_unlock(&mutex);
}

void* thread_work(void* arg) {
    long tid = (long)arg;
    for (int round = 0; round < ROUNDS; round++) {
        printf("Thread %ld: working in round %d\n", tid, round);
        barrier(THREAD_COUNT);
        sleep(1);
        printf("Thread %ld: passed barrier in round %d\n", tid, round);
    }
    return NULL;
}

int main() {
    pthread_t threads[THREAD_COUNT];
    for (long t = 0; t < THREAD_COUNT; t++)
        pthread_create(&threads[t], NULL, thread_work, (void*)t);
    for (int t = 0; t < THREAD_COUNT; t++)
        pthread_join(threads[t], NULL);
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond_var);
    return 0;
}
