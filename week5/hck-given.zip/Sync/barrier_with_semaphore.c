/*
    Semaphore Barrier Demonstration
    ------------------------------
    This code implements a barrier (synchronization point for threads) using two semaphores and a shared counter.
    - Threads call barrier() after some work and should only proceed once *all* have arrived.
    - The counter is protected by count_sem (a binary semaphore), barrier_sem is used for letting threads out.
    
    **Key explanation:**
    If a slow thread is stuck in round 1's barrier, and a fast thread races ahead to round 2,
    barrier_sem can be decremented by the fast thread when it enters sem_wait() in round 2 – consuming a signal
    that was intended for the slow thread in the first round. This breaks synchronization;
    one thread advances to the next barrier *before* the other has even left the previous round.
    This is a classic parallel programming race condition—semaphore barriers must be instrumented with extra logic
    (a generation or sense variable), or replaced with robust primitives (`pthread_barrier_t` in C), to be truly correct and reusable.
*/

#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h> // usleep

#define THREADS 2
#define ROUNDS 2

int counter = 0;
sem_t count_sem;     // Protects counter
sem_t barrier_sem;   // Used to block/release threads at the barrier

void barrier(int num_threads) {
    sem_wait(&count_sem);
    if (counter == num_threads - 1) {
        // Last thread to arrive resets counter and releases all others
        counter = 0; // Reset for reuse (but this is unsafe; see explanation above!)
        sem_post(&count_sem);
        for (int j = 0; j < num_threads - 1; j++)
            sem_post(&barrier_sem); // Wake up blocked threads
    } else {
        counter++;
        sem_post(&count_sem);
        sem_wait(&barrier_sem); // Wait for signal to proceed
    }
}

void* worker(void* arg) {
    long tid = (long)arg;
    for (int round = 0; round < ROUNDS; round++) {
        printf("Thread %ld: working in round %d\n", tid, round);
        if (tid == 0 && round == 0) usleep(300000); // Slow down thread 0 on first round
        barrier(THREADS);
        printf("Thread %ld: passed barrier in round %d\n", tid, round);
        // No sleep now; thread 0 catches up
    }
    return NULL;
}

int main() {
    pthread_t threads[THREADS];
    sem_init(&count_sem, 0, 1);
    sem_init(&barrier_sem, 0, 0);
    for (long t = 0; t < THREADS; t++)
        pthread_create(&threads[t], NULL, worker, (void*)t);
    for (int t = 0; t < THREADS; t++)
        pthread_join(threads[t], NULL);
    sem_destroy(&count_sem);
    sem_destroy(&barrier_sem);
    return 0;
}
