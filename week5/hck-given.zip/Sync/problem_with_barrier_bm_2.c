/*
    Attempting Multi-Use Barrier by Resetting the Counter (Incorrect!)
    ------------------------------------------------------------------
    This program shows why simply resetting the counter in a busy-wait barrier
    does NOT work for multiple rounds. When a thread resets the counter after
    passing the barrier, it can do so while other threads are still waiting or
    have not reached the barrier yet. This causes some threads to spin forever
    (deadlock), and others may skip proper synchronization altogether.

    Correct multi-use barriers require coordinated resets (with a sense flag or
    condition variables), not just counter resets. This example demonstrates a classic
    race condition and can hang, run out of order, or lose synchronization without warning.
*/
#include <pthread.h>
#include <stdio.h>
#define THREADS 3
#define ROUNDS 4

int counter = 0;
pthread_mutex_t barr_mutex;

void barrier(int total_threads, int round) {
    pthread_mutex_lock(&barr_mutex);
    counter++;
    pthread_mutex_unlock(&barr_mutex);
    while (counter < total_threads) {
        // busy-wait
    }
    // UNSAFE: Reset counter after all threads passed (broken)
    if (counter == total_threads) {
        counter = 0; // If one thread resets too soon, others can hang!
    }
}

/*in this version thread1 or 0 change the counter before thread 2 has reached the barrier*/

void* worker(void* arg) {
    for (int round = 0; round < ROUNDS; round++) {
        printf("Thread %ld: working in round %d\n", (long)arg, round);
        barrier(THREADS, round);
        printf("Thread %ld: passed barrier in round %d\n", (long)arg, round);
    }
    return NULL;
}

int main() {
    pthread_t threads[THREADS];
    pthread_mutex_init(&barr_mutex, NULL);
    for (long t = 0; t < THREADS; t++)
        pthread_create(&threads[t], NULL, worker, (void*)t);
    for (int t = 0; t < THREADS; t++)
        pthread_join(threads[t], NULL);
    pthread_mutex_destroy(&barr_mutex);
    return 0;
}
