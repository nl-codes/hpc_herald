/*
    Demo: pthread_rwlock_t (Read/Write Lock) Usage
    ---------------------------------------------------
    This program demonstrates a read/write lock for controlling concurrency:
    - Multiple threads can read a shared variable simultaneously (using rdlock).
    - Only one thread can write at a time (using wrlock), and readers are blocked during a write.

    Key points:
    - pthread_rwlock_t must be initialized (here with PTHREAD_RWLOCK_INITIALIZER).
    - Readers use pthread_rwlock_rdlock; writers use pthread_rwlock_wrlock.
    - After each operation, threads call pthread_rwlock_unlock to release the lock.
    - At the end, pthread_rwlock_destroy is called to free resources used by the lock.
    - Never re-initialize the lock while it is already in use or initialized; destroy first if needed.
*/

#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

#define READERS 3
#define WRITERS 1
#define ROUNDS 3

pthread_rwlock_t rwlock = PTHREAD_RWLOCK_INITIALIZER; // Correct static initialization
int shared_value = 0;

void* reader(void* arg) {
    long id = (long)arg;
    for (int r = 0; r < ROUNDS; ++r) {
        pthread_rwlock_rdlock(&rwlock); // Acquire read lock (shared)
        printf("Reader %ld reads shared_value = %d\n", id, shared_value);
        pthread_rwlock_unlock(&rwlock); // Release lock
        usleep(100000); // Sleep for demo clarity
        printf("Reader %ld ends round %d\n", id, r);
    }
    return NULL;
}

void* writer(void* arg) {
    long id = (long)arg;
    for (int r = 0; r < ROUNDS; ++r) {
        pthread_rwlock_wrlock(&rwlock); // Acquire write lock (exclusive)
        shared_value++;
        printf("Writer %ld writes shared_value = %d\n", id, shared_value);
        pthread_rwlock_unlock(&rwlock); // Release lock
        usleep(250000); // Sleep longer, shows reader concurrency
        printf("Writer %ld ends round %d\n", id, r);
    }
    return NULL;
}

int main() {
    pthread_t r[READERS], w[WRITERS];
    // (If you didn't use the static initializer, you'd need: pthread_rwlock_init(&rwlock, NULL); )
    for (long i = 0; i < READERS; ++i)
        pthread_create(&r[i], NULL, reader, (void*)i);
    for (long i = 0; i < WRITERS; ++i)
        pthread_create(&w[i], NULL, writer, (void*)i);

    for (int i = 0; i < READERS; ++i)
        pthread_join(r[i], NULL);
    for (int i = 0; i < WRITERS; ++i)
        pthread_join(w[i], NULL);
    pthread_rwlock_destroy(&rwlock); // Clean up resources
    return 0;
}
