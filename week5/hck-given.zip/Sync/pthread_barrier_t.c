/*
    Example: Using pthread_barrier_t for Thread Synchronization
    ---------------------------------------------------------
    This program demonstrates how to use a POSIX threads barrier (pthread_barrier_t) 
    to synchronize multiple threads in C.

    Key points:
    - pthread_barrier_t is initialized so all threads must reach the barrier before any can proceed.
    - Each thread prints a message before and after the barrier to show that they all
      wait at the barrier until everyone arrives, then all continue together.
    - Barriers are especially useful in parallel programs when you want all threads to
      finish a phase of work before starting the next phase.
    - After all threads are done, the barrier is destroyed to release resources.
*/

#include <pthread.h>
#include <stdio.h>
#define THREADS 3
pthread_barrier_t barrier;

void* work(void* arg) {
    printf("Thread %ld before barrier\n", (long)arg);
    pthread_barrier_wait(&barrier); // All threads pause here until every thread arrives
    printf("Thread %ld after barrier\n", (long)arg); // All threads resume together
    return NULL;
}

int main() {
    pthread_t t[THREADS];
    pthread_barrier_init(&barrier, NULL, THREADS); // Init barrier for 3 threads
    for (long i = 0; i < THREADS; ++i)
        pthread_create(&t[i], NULL, work, (void*)i);
    for (int i = 0; i < THREADS; ++i)
        pthread_join(t[i], NULL);
    pthread_barrier_destroy(&barrier); // Clean up barrier
    return 0;
}
