/*
    Broken Multi-Use Barrier Example (Busy Wait, Single Counter)
    ----------------------------------------------------------
    This program shows how using a single counter and busy waiting cannot create
    a correct multi-use barrier. In the first use, all threads increment the counter
    and wait for every thread to arrive. On subsequent uses, the counter is already
    at the thread count, so all threads pass through the barrier immediately,
    breaking synchronization. Attempts to reset the counter without additional logic
    (like a sense variable, or condition variable) can introduce deadlocks or race conditions.
    
    Lesson: Using a plain busy-wait loop and counter (without a reset mechanism that is
    safe and atomic for all threads) does not work for barriers that must be reused
    in loops or multi-phase programs.
*/

#include <pthread.h>
#include <stdio.h>
#define THREADS 3
#define ROUNDS 4

int counter = 0;             // Counts how many threads arrive at barrier
pthread_mutex_t barr_mutex;  // Mutex to protect counter increments

// Broken (non-reusable) barrier: only works once!
void barrier(int total_threads) {
    pthread_mutex_lock(&barr_mutex);
    counter++;
    pthread_mutex_unlock(&barr_mutex);
    while (counter < total_threads) {
        // busy-wait (wastes CPU, but that's not the main demo issue)
    }
}

void* worker(void* arg) {
    for (int round = 0; round < ROUNDS; round++) {
        printf("Thread %ld: working in round %d\n", (long)arg, round);
        barrier(THREADS);
        printf("Thread %ld: passed barrier in round %d\n", (long)arg, round);
    }
    return NULL;
}

int main() {
    pthread_t threads[THREADS];
    pthread_mutex_init(&barr_mutex, NULL);
    for (long t = 0; t < THREADS; t++)
        pthread_create(&threads[t], NULL, worker, (void*)t);
    for (int t = 0; t < THREADS; t++)
        pthread_join(threads[t], NULL);
    pthread_mutex_destroy(&barr_mutex);
    return 0;
}
