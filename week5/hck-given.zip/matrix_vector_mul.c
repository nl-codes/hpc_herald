/****************************************************************************
  Serial Matrix-Vector Multiplication with Timing

  This program demonstrates how to multiply a matrix (A) by a vector (x)
  using a serial (single-threaded) algorithm. It reports the elapsed time 
  required for the computation in nanoseconds by utilizing the 
  time_difference() function from "time_diff.h".

  Key Concepts:
    - Matrix A has M rows and N columns.
    - Vector x has N elements.
    - The result vector y has M elements, where each y[i] is the dot product of
      the i-th row of A and the vector x.
    - Timing functions use POSIX clock_gettime and a utility function to compute
      elapsed time precisely.

  Dependencies:
    - Requires the "time_diff.h" header for time measurement.
  
    Compile with: 
    gcc -o matrix_vector_mul matrix_vector_mul.c time_diff.c -lrt


****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "time_diff.h"  // Contains time_difference()

#define M 800   // Number of rows
#define N 400   // Number of columns

int m = M, n = N;

int main() {
    double A[M][N];
    double x[N];
    double y[M];

    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            A[i][j] = (i+1) * (j+1);
    for (int i = 0; i < n; i++)
        x[i] = 1.0;
    

    struct timespec start, finish;
    long long int elapsed;

    // Start timer
    clock_gettime(CLOCK_MONOTONIC, &start);

    // Serial matrix-vector multiplication
    for (int i = 0; i < M; i++) {
        y[i] = 0.0;
        for (int j = 0; j < N; j++) {
            y[i] += A[i][j] * x[j];
        }
    }

    // Stop timer
    clock_gettime(CLOCK_MONOTONIC, &finish);

    // Calculate elapsed time in nanoseconds
    time_difference(&start, &finish, &elapsed);
    printf("Elapsed time: %lld ns\n", elapsed);

    // Output result
    // printf("Result y = [ ");
    // for (int i = 0; i < M; i++) {
    //     printf("%f ", y[i]);
    // }
    // printf("]\n");

    return 0;
}
