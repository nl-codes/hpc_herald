/****************************************************************************
  Parallel Matrix-Vector Multiplication Using POSIX Threads (pthreads)

  This program multiplies a matrix (A) by a vector (x) using multiple threads.
  Each thread is responsible for computing a contiguous block of output vector y.

  Key Concepts:
    - Matrix A has m rows and n columns (both global).
    - Vector x has n elements, output vector y has m elements.
    - thread_count threads are created; each computes m/thread_count rows.
    - All input and output arrays are shared/global.
    - Work distribution avoids race conditions, so no explicit locking is required.
    - Timing functions use POSIX clock_gettime and a utility function.

  Usage:
    - Compile with: 
    gcc -o matvec_parallel matvec_parallel.c time_diff.c -pthread -lrt

****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include "time_diff.h"   // Provides time_difference()

#define M 800  // Number of rows
#define N 400    // Number of columns

int m = M, n = N;
int thread_count = 4;
double A[M][N];
double x[N];
double y[M];

void *Pth_mat_vect(void* rank);

int main() {
    // Initialize matrices and vectors with some values
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            A[i][j] = (i+1) * (j+1);
    for (int i = 0; i < n; i++)
        x[i] = 1.0;
    
    pthread_t threads[thread_count];
    long thread;
    struct timespec start, finish;
    long long int elapsed;

    clock_gettime(CLOCK_MONOTONIC, &start);

    // Create threads
    for (thread = 0; thread < thread_count; thread++)
        pthread_create(&threads[thread], NULL, Pth_mat_vect, (void*)thread);

    // Join threads
    for (thread = 0; thread < thread_count; thread++)
        pthread_join(threads[thread], NULL);

    clock_gettime(CLOCK_MONOTONIC, &finish);
    time_difference(&start, &finish, &elapsed);
    printf("Elapsed time: %lld ns\n", elapsed);

    // printf("Result y = [ ");
    // for (int i = 0; i < m; i++)
    //     printf("%f ", y[i]);
    // printf("]\n");
    // return 0;
}

/* ------------------------------------------------------------------------
   Each thread computes a block of consecutive rows of the output vector y.
   Arrays A, x, y, and values m, n, thread_count are shared and global.
   This function is safe because each thread writes exclusive elements in y.
   ------------------------------------------------------------------------ */
void *Pth_mat_vect(void* rank) {
    long my_rank = (long) rank;
    int i, j;
    int num_of_rows_per_thread = m / thread_count;
    int my_first_row = my_rank * num_of_rows_per_thread;
    int my_last_row = (my_rank == (thread_count - 1))? (m - 1) : (my_rank+1) * num_of_rows_per_thread - 1;

    for (i = my_first_row; i <= my_last_row; i++) {
        y[i] = 0.0;
        for (j = 0; j < n; j++)
            y[i] += A[i][j] * x[j];
    }
    return NULL;
}
