/*
    Parallel Pi Calculation using Leibniz Series, Mutex Protection, and Timing
    ------------------------------------------------------------------------
    This program divides the computation of pi (using the Leibniz alternating series)
    among several threads. A mutex protects updates to the shared sum variable. 
    'time_diff.h' is used with clock_gettime to measure and display elapsed time in seconds.
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include "time_diff.h"

#define THREAD_COUNT 20
#define N_TERMS 100000000LL

double sum = 0.0;
pthread_mutex_t sum_mutex; // Mutex for protecting sum

void* Thread_sum(void* rank) {
    long my_rank = (long) rank;
    long long my_n = N_TERMS / THREAD_COUNT;
    long long my_first_i = my_n * my_rank;
    long long my_last_i = my_first_i + my_n;
    double factor = (my_first_i % 2 == 0) ? 1.0 : -1.0;
    double local_sum = 0.0;
    for (long long i = my_first_i; i < my_last_i; i++, factor = -factor) {
        local_sum += factor / (2 * i + 1);
    }
    pthread_mutex_lock(&sum_mutex);
    sum += local_sum;
    pthread_mutex_unlock(&sum_mutex);
    return NULL;
}

int main() {
    pthread_t threads[THREAD_COUNT];
    pthread_mutex_init(&sum_mutex, NULL);
    struct timespec start, finish;
    long long int elapsed_ns;

    clock_gettime(CLOCK_MONOTONIC, &start); // Start timing
    for (long t = 0; t < THREAD_COUNT; t++)
        pthread_create(&threads[t], NULL, Thread_sum, (void*)t);
    for (long t = 0; t < THREAD_COUNT; t++)
        pthread_join(threads[t], NULL);
    clock_gettime(CLOCK_MONOTONIC, &finish); // End timing
    
    pthread_mutex_destroy(&sum_mutex);

    time_difference(&start, &finish, &elapsed_ns);

    double elapsed_sec = elapsed_ns / 1e9;
    double pi = 4.0 * sum;
    printf("Estimated value of pi (with mutex): %.15f\n", pi);
    printf("Elapsed time: %.6f seconds\n", elapsed_sec);
    return 0;
}
