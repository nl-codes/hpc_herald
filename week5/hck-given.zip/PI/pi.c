/*
    Parallel Pi Calculation using the Leibniz Series (Without Mutex)
    --------------------------------------------------------------
    This program estimates pi by dividing the Leibniz series among several threads.
    Each thread works on its block of terms and directly adds its partial result to a shared variable.

    No synchronization (mutex/semaphore) is used, so concurrent threads may overwrite each other's updates.
    This creates a race condition. As a result, the computed value of pi will be inaccurate and unpredictable.
    This example demonstrates the need for protecting shared data in parallel programs.

    Try experimenting:
    - Increase the number of terms (N_TERMS), or number of threads (THREAD_COUNT).
    - Run the program multiple times: The output will change and will not converge to the correct value.
    - Add a mutex around the update to 'sum' and compare the results!
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "time_diff.h"

#define THREAD_COUNT 4
#define N_TERMS 100000000LL

double sum = 0.0; // shared variable (no protection!)

// Each thread computes a block of the Leibniz series
void* Thread_sum(void* rank) {
    long my_rank = (long) rank;
    long long my_n = N_TERMS / THREAD_COUNT;
    long long my_first_i = my_n * my_rank;
    long long my_last_i = my_first_i + my_n;
    double factor = (my_first_i % 2 == 0) ? 1.0 : -1.0;

    for (long long i = my_first_i; i < my_last_i; i++, factor = -factor) {
        sum += factor / (2 * i + 1); 
    }
    return NULL;
}

int main() {
    pthread_t threads[THREAD_COUNT];
    struct timespec start, finish;
    long long elapsed;

    clock_gettime(CLOCK_MONOTONIC, &start);
    

    for (long t = 0; t < THREAD_COUNT; t++)
        pthread_create(&threads[t], NULL, Thread_sum, (void*)t);

    for (long t = 0; t < THREAD_COUNT; t++)
        pthread_join(threads[t], NULL);
    double pi = 4.0 * sum;
    clock_gettime(CLOCK_MONOTONIC, &finish);
    time_difference(&start, &finish, &elapsed);
    printf("Elapsed time: %fs\n", elapsed/1000000000.0);
    printf("Estimated value of pi (no mutex): %.15f\n", pi);
    return 0;
}
