/*
    Pi Calculation Using Leibniz Series with Busy Waiting
    ---------------------------------------------------
    This program splits the terms of the Leibniz series for pi into blocks,
    assigns each block to a thread, and uses busy waiting to mutually exclude
    updates to the shared variable 'sum'. Only the thread whose turn matches
    'flag' proceeds; others spin until their turn. This avoids race conditions,
    but is less efficient than using mutexes or atomic variables.

    Try increasing threads (THREAD_COUNT) and N_TERMS
    - The calculated result approaches pi and is accurate
    - Program speed slows as threads spend time busy waiting
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "time_diff.h"

#define THREAD_COUNT 20
#define N_TERMS 100000000LL

volatile int flag = 0; // Controls which thread may enter critical section

double sum = 0.0; // Shared result

void* Thread_sum(void* rank) {
    long my_rank = (long) rank;
    long long my_n = N_TERMS / THREAD_COUNT;
    long long my_first_i = my_n * my_rank;
    long long my_last_i = my_first_i + my_n;
    double local_sum = 0.0;
    double factor = (my_first_i % 2 == 0) ? 1.0 : -1.0;

    for (long long i = my_first_i; i < my_last_i; i++, factor = -factor) {
        local_sum += factor / (2 * i + 1);
    }

    while (flag != my_rank); // Busy waiting
    sum += local_sum;
    flag = (my_rank + 1) % THREAD_COUNT;
    return NULL;
}

int main() {
    pthread_t threads[THREAD_COUNT];
    struct timespec start, finish;
    long long int elapsed;

    clock_gettime(CLOCK_MONOTONIC, &start); // Start timing
    for (long t = 0; t < THREAD_COUNT; t++)
        pthread_create(&threads[t], NULL, Thread_sum, (void*)t);
    for (long t = 0; t < THREAD_COUNT; t++)
        pthread_join(threads[t], NULL);
    clock_gettime(CLOCK_MONOTONIC, &finish); // End timing

    time_difference(&start, &finish, &elapsed);
    printf("Elapsed time: %fs\n", elapsed/1000000000.0); // Output time

    double pi = 4.0 * sum;
    printf("Estimated pi: %.15f\n", pi);
    return 0;
}
